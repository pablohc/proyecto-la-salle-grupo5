<template>
    <footer id="footer">
        Grupo 5: Pablo, Isabel, Marta, Elionor, Marc
    </footer>
</template>
  
<script setup>

</script>
  
<style scoped>
    #footer {
        display: flex;
        justify-content: center;
        align-items: center;
        background: rgb(147, 198, 243);
        font-family: sans-serif;
        width: 98vw;
        height: 6vh;
        position: sticky;
        top: 98vh;
        text-align: center;
    }
  </style>